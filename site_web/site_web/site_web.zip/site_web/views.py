from django.http import HttpResponse
from django.shortcuts import render

from .db_ateliers import ateliers

def home_views(request):
    #return HttpResponse('Hello world') 
    return render(request, 'home.html')
def contact_views(request):
    #return HttpResponse('Contactez nous')
    return render(request, 'contact.html')

def article_views(request):
    return render(request, 'ateliers.html', context={'ateliers': ateliers})