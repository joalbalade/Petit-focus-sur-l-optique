from django.contrib import admin
from django.urls import path, include

from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home_views, name='Home'),
    path('contact/', views.contact_views, name='Contact'),
    path('Ateliers/', views.article_views, name='Ateliers'),
]
