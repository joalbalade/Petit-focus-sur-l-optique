ateliers = [
    {
        "titre": "Premier atelier - Les lentilles",
        "date_publication": "30/01/2022",
        "contenu": "Réflexion, réfraction par des dioptres, miroirs, fonctionnement de l'oeil et correction de la vision."
    },
    
    {
        "titre": "Second atelier - Les lasers et la fibre optique",
        "date_publication": "30/01/2022",
        "contenu": "Expérience de création d'un laser, correction puis cours sur le fonctionnement (analogie avec la lumière naturelle) et expérience sur la transmission du son, cours et expériences sur la fibre optique, Quizz sur le contenu de la séance."
    },
    
    {
        "titre": "Troisième atelier - La caméra",
        "date_publication": "30/01/2022",
        "contenu": "Contenu du troisième atelier"
    }
]